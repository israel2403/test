package com.oxxo.microservice.crearproveedoresorden.entity;
import lombok.Data;
import jakarta.persistence.*;
import java.util.Date;


@Entity
@Table(name="NB_CITAS_SUPS_STG", schema = "wmuser")
@Data
public class ProveedorEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_SUPS")
    private Integer idProveedor;

    @Column(name = "EXTERNAL_REF")
    private String referenciaExterna;

    @Column(name = "BUSINESS_NAME")
    private String razonSocial;

    @Column(name = "OPERATION_LOC")
    private String operacion;

    @Column(name = "PHONE")
    private String telefono;

    @Column(name = "PHONE_2")
    private String telefono2;

    @Column(name = "PHONE_3")
    private String telefono3;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "TAX_BUSINESS_NAME")
    private String razonSocialFiscal;

    @Column(name = "TAX_IDENTIFIER")
    private String identificadorFiscal;

    @Column(name = "CONTACT")
    private String contacto;

    @Column(name = "ADDRESS")
    private String direccion;

    @Column(name = "STREET")
    private String calle;

    @Column(name = "ADDR_NUMBER")
    private String numeroPuerta;

    @Column(name = "DISTRICT")
    private String barrio;

    @Column(name = "CITY")
    private String localidad;

    @Column(name = "ADDR_TOWN")
    private String partido;

    @Column(name = "ADDR_STATE")
    private String provincia;

    @Column(name = "COUNTRY")
    private String pais;

    @Column(name = "POSTCODE")
    private String codigoPostal;

    @Column(name = "VARCHAR_1")
    private String texto1;

    @Column(name = "VARCHAR_2")
    private String texto2;

    @Column(name = "VARCHAR_3")
    private String texto3;

    @Column(name = "ID_STATUS")
    private Long idEstado;

    @Column(name = "LOGIN")
    private String login;

    @Column(name = "STATUS_APPT_SLOT_INIT_GRP")
    private String edoCitaSlotGpoIni;

    @Column(name = "STATUS_APPT_SLOT_INIT")
    private String edoCitaSlotIni;

    @Column(name = "SUPPS_PARENT_ORD")
    private String proveedorOrdenPadre;

    @Column(name = "DEPOSIT_RESET")
    private Integer depositosReset;

    @Column(name = "NUMBER_1")
    private Integer numero1;

    @Column(name = "NUMBER_2")
    private Integer numero2;

    @Column(name = "NUMBER_3")
    private Integer numero3;

    @Column(name = "FLOAT_1")
    private Double decimal1;

    @Column(name = "FLOAT_2")
    private Double decimal2;

    @Column(name = "FLOAT_3")
    private Double decimal3;

    @Column(name = "START_TIME_1")
    private Integer inicioHorario1;

    @Column(name = "END_TIME_1")
    private Integer finHorario1;

    @Column(name = "START_TIME_2")
    private Integer inicioHorario2;

    @Column(name = "END_TIME_2")
    private Integer finHorario2;

    @Column(name = "ENABLED_APPT")
    private Integer habilitadoCitas;

    @Column(name = "LONGITUDE")
    private Double longitud;

    @Column(name = "LATITUDE")
    private Double latitud;

    @Column(name = "SINGLE_APPT")
    private Integer citaUnica;

    @Column(name = "APPT_ORD_WO")
    private Integer citaPorOrdenOt;

    @Column(name = "RECEIVE_NOTIFICATION")
    private Integer recibeNotificaciones;

    @Column(name = "PROCESS_IND")
        private String procesado;

    @Column(name = "CREATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCreacion;

    @Column(name = "EXTRACT_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaExtraccion;

    @Column(name = "AUX_NUMBER_1")
    private Integer campoNumerico1;

    @Column(name = "AUX_NUMBER_2")
    private Integer campoNumerico2;

    @Column(name = "AUX_NUMBER_3")
    private Integer campoNumerico3;

    @Column(name = "AUX_VARCHAR_1")
    private String campoTexto1;

    @Column(name = "AUX_VARCHAR_2")
    private String campoTexto2;

    @Column(name = "AUX_VARCHAR_3")
    private String campoTexto3;

}
