package com.oxxo.microservice.crearproveedoresorden.unigis.service;

import com.oxxo.microservice.crearproveedoresorden.unigis.model.rms.UnigisAuth;
import com.oxxo.microservice.crearproveedoresorden.unigis.repository.UnigisAuthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UnigisAuthService {

    @Autowired
    UnigisAuthRepository repository;


    public Optional<UnigisAuth> getActiveEnviromentData(String enviroment){
        return repository.findUnigisAuthByEnviroment(enviroment);
    }
}
