package com.oxxo.microservice.crearproveedoresorden.unigis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UnigisAuthResult
{
    @JsonProperty("Result")
    private String result;

    @JsonProperty("Message")
    private String message;

    @JsonProperty("User")
    private String user;

    @JsonProperty("Group")
    private String group;

    @JsonProperty("Token")
    private String token;

    @JsonProperty("MapiToken")
    private String mapiToken;

    @JsonProperty("JWT")
    private String jwt;

    @JsonProperty("TimeoutJWT")
    private String timeoutJWT;

    @JsonProperty("Actions")
    private String actions;

    @JsonProperty("Properties")
    private String properties;

    @JsonProperty("GruposUsuarios")
    private String gruposUsuarios;
}
