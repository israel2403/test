package com.oxxo.microservice.crearproveedoresorden.service;

import com.oxxo.microservice.crearproveedoresorden.unigis.service.PostUnigisService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@RequiredArgsConstructor
public class ScheduledTaskService {

    private static final Logger logger = LoggerFactory.getLogger(ScheduledTaskService.class);
    private final PostUnigisService postUnigisService;

    @Scheduled(fixedRate = 1800000)  // 30 minutes in milliseconds
    public void listarProveedoresV1() throws IOException, InterruptedException {
        logger.info("Scheduled task to create order for provider.");

        Map<String, String> body;
        try {
            body = postUnigisService.createOT();
            logger.info("Successfully created order for provider with response: {}", body);
        } catch (IOException | InterruptedException e) {
            logger.error("Error occurred while creating order for provider: {}", e.getMessage(), e);
            throw e;
        }
    }
}

