package com.oxxo.microservice.crearproveedoresorden.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "NB_CITAS_PROVEEDOR_DEP_STG", schema = "WMUSER")
public class CitaProveedorDeposito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_DEPOSITO")
    private Long idDeposito;

    @Column(name = "ID_PROVEEDOR")
    private Long idProveedor;

    @Column(name = "DEPOSITO")
    private String deposito;

    @Column(name = "CANTIDAD_CITAS_MAXIMA")
    private Integer cantidadCitasMaxima;
}