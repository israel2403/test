package com.oxxo.microservice.crearproveedoresorden.unigis.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.oxxo.microservice.crearproveedoresorden.clients.ErrorsClient;
import com.oxxo.microservice.crearproveedoresorden.dto.ErrorDetailsDTO;
import com.oxxo.microservice.crearproveedoresorden.entity.ProveedorEntity;
import com.oxxo.microservice.crearproveedoresorden.service.CatProveedorService;
import com.oxxo.microservice.crearproveedoresorden.unigis.model.UnigisAuthResult;
import com.oxxo.microservice.crearproveedoresorden.unigis.model.rms.UnigisAuth;
import com.oxxo.microservice.crearproveedoresorden.unigis.model.rms.UnigisOperation;
import com.oxxo.microservice.crearproveedoresorden.unigis.model.supplier.UnigisProveedor;
import com.oxxo.microservice.crearproveedoresorden.unigis.model.supplier.UnigisProveedorEntity;
import com.oxxo.microservice.crearproveedoresorden.utils.UnigisConstants;
import com.oxxo.microservice.crearproveedoresorden.utils.UnigisOperationsEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PostUnigisService {

    @Autowired
    ErrorsClient errorsClient;

    @Autowired
    UnigisAuthService unigisAuthService;

    @Autowired
    UnigisOperationService unigisOperationService;

    @Autowired
    CatProveedorService catProveedorService;

    private static final Logger logger = LoggerFactory.getLogger(CatProveedorService.class);

    private final HttpClient httpClient = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_2)
            .build();

    public Map<String, String> createOT() throws IOException, InterruptedException {
        Map<String, String> body = new HashMap<>();
        logger.info("Fetching active environment data for '{}'", UnigisConstants.DES.getValue());
        Optional<UnigisAuth> unigisAuth = unigisAuthService.getActiveEnviromentData(UnigisConstants.DES.getValue());
        if (unigisAuth.isPresent()) {
            logger.info("UnigisAuth data found");
            Optional<UnigisOperation> unigisOperation = unigisOperationService.getActiveEnviromentData(UnigisConstants.DES.getValue(), UnigisOperationsEnum.PROVEEDOR.label);
            if (unigisOperation.isPresent()) {
                logger.info("UnigisOperation data found");
                UnigisAuthResult unigisAuthResult = getBearerToken(unigisAuth.get());
                List<ProveedorEntity> proveedorEntityList = catProveedorService.listarProveedores();
                logger.info("Obtaining proveedores with Procesado '{}'", UnigisConstants.PROCESADO.getValue());
                String result = obtenerProveedores(unigisAuthResult, unigisOperation.get(), unigisAuth.get().getApiKey(), proveedorEntityList);
                body.put("message", Objects.requireNonNullElse(result, UnigisConstants.UNIGIS_ERROR.getValue()));
                if (result.equals("{\"d\":1}")) {
                    logger.info("Setting Procesado to '{}' for all proveedores", UnigisConstants.PROCESADO.getValue());
                    proveedorEntityList.forEach(p -> p.setProcesado(UnigisConstants.PROCESS_IND_P.getValue()));
                    this.catProveedorService.saveAllProveedores(proveedorEntityList);
                } else {
                    logger.info("Setting Procesado to '{}' for all proveedores", UnigisConstants.PROCESS_IND_E.getValue());
                    proveedorEntityList.forEach(p -> p.setProcesado(UnigisConstants.PROCESS_IND_E.getValue()));
                    this.catProveedorService.saveAllProveedores(proveedorEntityList);
                }
            } else {
                logger.error(UnigisConstants.NO_UNIGIS_OPERATION_FOUND.getValue());
                body.put("message", UnigisConstants.NO_UNIGIS_OPERATION_FOUND.getValue());
                try {
                    String date = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT);
                    ErrorDetailsDTO dto = new ErrorDetailsDTO(500, "Error en el microservicio CrearProveedor | " + UnigisConstants.NO_UNIGIS_OPERATION_FOUND.getValue(), "no data", date);
                    errorsClient.saveErrors(dto);
                } catch (Exception e) {
                    logger.error(UnigisConstants.ERROR_LOG_REGISTER_FAILED.getValue(), e);
                    body.put("error", UnigisConstants.ERROR_LOG_REGISTER_FAILED.getValue());
                }
            }
        } else {
            logger.error(UnigisConstants.NO_AUTH_UNIGIS_DATA_FOUND.getValue());
            body.put("message", UnigisConstants.NO_AUTH_UNIGIS_DATA_FOUND.getValue());
        }
        return body;
    }

    private String obtenerProveedores(UnigisAuthResult auth, UnigisOperation operation, String apiKey, List<ProveedorEntity> proveedorEntityList) throws IOException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Set<UnigisProveedor> unigisProveedorSet = proveedorEntityList.stream().map(this::fromProveedorEntityToUnigisProveedor).collect(Collectors.toSet());
        UnigisProveedorEntity unigisProveedor = UnigisProveedorEntity.builder()
                .apiKey(apiKey)
                .proveedoresOrden(List.copyOf(unigisProveedorSet))
                .build();
        String URL = operation.getUrl();
        logger.info("Sending request to URL: {}", URL);
        HttpRequest request = HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(unigisProveedor)))
                .uri(URI.create(URL))
                .header(UnigisConstants.AUTHORIZATION.getValue(), UnigisConstants.BEARER.getValue() + " " + auth.getJwt())
                .setHeader(UnigisConstants.USER_AGENT.getValue(), UnigisConstants.OXXO_MS_TEST.getValue()) // add request header
                .header(UnigisConstants.CONTENT_TYPE.getValue(), MediaType.APPLICATION_JSON_VALUE)
                .header(UnigisConstants.ACCEPT_LABEL.getValue(),UnigisConstants.ACCEPT_VALUE.getValue())
                .header(UnigisConstants.ACCEPT_ENCODING_LABEL.getValue(),UnigisConstants.ACCEPT_ENCODING.getValue())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        logger.info("Response status code: {}", response.statusCode());
        logger.info("Response body: {}", response.body());
        return response.body();
    }

    private UnigisProveedor fromProveedorEntityToUnigisProveedor(ProveedorEntity proveedorEntity) {
        return UnigisProveedor.builder()
                .barrio(proveedorEntity.getBarrio())
                .calle(proveedorEntity.getCalle())
                .nbCitasProveedorDepStg(proveedorEntity.getIdProveedor() != null ? proveedorEntity.getIdProveedor() : 0)
                .codigoPostal(proveedorEntity.getCodigoPostal())
                .contacto(proveedorEntity.getContacto())
                .depositosReset(proveedorEntity.getDepositosReset() != null && proveedorEntity.getDepositosReset() == 1)
                .direccion(proveedorEntity.getDireccion())
                .email(proveedorEntity.getEmail())
                .identificadorFiscal(proveedorEntity.getIdentificadorFiscal())
                .localidad(proveedorEntity.getLocalidad())
                .numeroPuerta(proveedorEntity.getNumeroPuerta())
                .operacion(proveedorEntity.getOperacion() != null ? Long.parseLong(proveedorEntity.getOperacion()) : 0L)
                .pais(proveedorEntity.getPais())
                .partido(proveedorEntity.getPartido())
                .proveedorOrdenPadre(proveedorEntity.getProveedorOrdenPadre())
                .provincia(proveedorEntity.getProvincia())
                .razonSocial(proveedorEntity.getRazonSocial())
                .razonSocialFiscal(proveedorEntity.getRazonSocialFiscal())
                .recibeNotificaciones(proveedorEntity.getRecibeNotificaciones() != null && proveedorEntity.getRecibeNotificaciones() == 1)
                .referenciaExterna(proveedorEntity.getReferenciaExterna())
                .sincronizarUsuario(Boolean.TRUE)
                .telefono(proveedorEntity.getTelefono() != null ? Integer.parseInt(proveedorEntity.getTelefono()) : 0)
                .login(proveedorEntity.getLogin())
                .cantidadMaximaCitasPorDia(-1)
                .build();
    }

    public UnigisAuthResult getBearerToken(UnigisAuth auth) throws IOException, InterruptedException {
        String authURL = auth.getUrl();
        logger.info("Requesting bearer token from URL: {}", authURL);
        ObjectMapper objectMapper = new ObjectMapper();
        HttpRequest request = HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(auth)))
                .uri(URI.create(authURL))
                .setHeader(UnigisConstants.USER_AGENT.getValue(), UnigisConstants.OXXO_MS_TEST.getValue()) // add request header
                .header(UnigisConstants.CONTENT_TYPE.getValue(), MediaType.APPLICATION_JSON_VALUE)
                .header(UnigisConstants.ACCEPT_LABEL.getValue(),UnigisConstants.ACCEPT_VALUE.getValue())
                .header(UnigisConstants.ACCEPT_ENCODING_LABEL.getValue(),UnigisConstants.ACCEPT_ENCODING.getValue())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        logger.info("Bearer token response status code: {}", response.statusCode());
        logger.info("Bearer token response body: {}", response.body());

        UnigisAuthResult result = objectMapper.readValue(response.body(), UnigisAuthResult.class);
        logger.info("Bearer token obtained: {}", result);
        return result;
    }
}
