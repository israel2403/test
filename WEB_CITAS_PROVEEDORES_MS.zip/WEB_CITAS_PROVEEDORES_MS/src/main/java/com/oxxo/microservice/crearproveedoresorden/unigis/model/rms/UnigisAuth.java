package com.oxxo.microservice.crearproveedoresorden.unigis.model.rms;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "DT_UNIGIS_AUTH")
public class UnigisAuth {

    @Id
    @Column(name = "DTID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;


    @JsonProperty("user")
    @Column(name = "UNI_USER")
    private String user;

    @Column(name = "UNI_PASS")
    @JsonProperty("password")
    private String password;

    @Column(name = "UNI_SYSTEM")
    @JsonProperty("system")
    private String system;

    @Column(name = "UNI_API_KEY")
    @JsonProperty("ApiKey")
    private String apiKey;

    @Column(name = "UNI_TENANT")
    @JsonProperty("tenant")
    private String tenant;

    @Column(name = "UNI_ENVIROMENT")
    private String enviroment;

    @Column(name = "UNI_ACTIVE")
    private int active;

    @Column(name = "UNI_URL")
    private String url;
}
