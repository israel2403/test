package com.oxxo.microservice.crearproveedoresorden.service;

import com.oxxo.microservice.crearproveedoresorden.entity.ProveedorEntity;
import com.oxxo.microservice.crearproveedoresorden.repository.CatProveedorServicieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CatProveedorService implements ICatProveedorService {

    private static final Logger logger = LoggerFactory.getLogger(CatProveedorService.class);

    @Autowired
    private CatProveedorServicieRepository proveedorRepository;

    public List<ProveedorEntity> get(){
        return  proveedorRepository.findAll();
    }

    @Override
    public List<ProveedorEntity> listarProveedores() {
        logger.info("Fetching proveedores with PROCESS_IND like 'N'");
        Set<ProveedorEntity> proveedores = proveedorRepository.findByProcesadoLike("N");
        logger.info("Proveedores fetched with PROCESS_IND like 'N' : {}", proveedores.size());

        logger.info("Partitioning proveedores based on non-null RECEIVE_NOTIFICATION and DEPOSIT_RESET");
        Map<Boolean, List<ProveedorEntity>> partitionedProveedores = proveedores.stream()
                .collect(Collectors.partitioningBy(
                        p -> p.getRecibeNotificaciones() == null || p.getDepositosReset() == null
                ));
        logger.info("partitionedProveedores: {}", partitionedProveedores.size());
        List<ProveedorEntity> withNonNullValues = partitionedProveedores.get(false);
        List<ProveedorEntity> withNullValues = partitionedProveedores.get(true);

        logger.info("Proveedores with non-null RECEIVE_NOTIFICATION and DEPOSIT_RESET: {}", withNonNullValues.size());
        logger.info("Proveedores with null RECEIVE_NOTIFICATION or DEPOSIT_RESET: {}", withNullValues.size());

        // Set the PROCESS_IND to 'E' for proveedores with null RECEIVE_NOTIFICATION or DEPOSIT_RESET
        logger.info("Setting PROCESS_IND to 'E' for proveedores with null RECEIVE_NOTIFICATION or DEPOSIT_RESET");
        withNullValues.forEach(p -> p.setProcesado("E"));

        if (!withNullValues.isEmpty()) {
            logger.info("!withNullValues.isEmpty(): {}", withNullValues);
            logger.info("Saving modified proveedores with PROCESS_IND set to 'E'");
            proveedorRepository.saveAll(withNullValues);
            logger.info("Saved {} proveedores with PROCESS_IND set to 'E'", withNullValues.size());
        }

        logger.info("Returning proveedores with non-null RECEIVE_NOTIFICATION and DEPOSIT_RESET");
        return withNonNullValues;
    }

    @Override
    public void saveAllProveedores(List<ProveedorEntity> proveedorEntityList) {
        this.proveedorRepository.saveAll(proveedorEntityList);
    }
}
