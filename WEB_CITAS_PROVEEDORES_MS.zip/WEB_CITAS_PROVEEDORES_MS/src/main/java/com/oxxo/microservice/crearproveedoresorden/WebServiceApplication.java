package com.oxxo.microservice.crearproveedoresorden;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@SpringBootApplication
@EnableWebMvc
@EnableFeignClients
@EnableScheduling
public class WebServiceApplication {

	//public static void main(String[] args) {
	//	SpringApplication.run(WebServiceApplication.class, args);
	//}

	private static final Logger logger = LoggerFactory.getLogger(WebServiceApplication.class);
	public static void main(String[] args) {
		logStartupInfo();

		AtomicBoolean exito = new AtomicBoolean(false);
		int intentosMaximos = 5;

		AtomicReference<ConfigurableApplicationContext> applicationContextRef = new AtomicReference<>();

		for (int intento = 1; intento <= intentosMaximos && !exito.get(); intento++) {
			try {

				Thread connectionThread = new Thread(() -> {
					try {
						SpringApplication application = new SpringApplication(WebServiceApplication.class);
						application.addListeners(new ApplicationFailedListener());
						application.addListeners(new ApplicationStartedListener());
						ConfigurableApplicationContext context = application.run(args);
						applicationContextRef.set(context);
						exito.set(true);
						System.out.println("Conexion exitosa. La aplicacion continuara su ejecucion.");
					} catch (Exception e) {
						System.out.println("Error al conectar en el hilo: " + e.getMessage());
					}
				});

				connectionThread.start();
				connectionThread.join();

				ConfigurableApplicationContext applicationContext = applicationContextRef.get();
				if (exito.get() && applicationContext != null) {
					break;
				} else {
					System.out.println("Intento de conexion fallido (Intento " + intento + "/" + intentosMaximos + ")." +
							" Esperando 5 minutos antes de reintentar.");
					try {
						Thread.sleep(300000);
					} catch (InterruptedException ex) {
						Thread.currentThread().interrupt();
					}
				}
			} catch (Exception e) {
				System.out.println("Error al crear el hilo: " + e.getMessage());
			}
		}

		if (!exito.get()) {
			ConfigurableApplicationContext applicationContext = applicationContextRef.get();
			if (applicationContext != null && applicationContext.isRunning()) {
				applicationContext.close();
			}
			System.out.println("Bucle terminado -----");
		}
	}


	private static void printHostInfo() {
		try {
			InetAddress inetAddress = InetAddress.getLocalHost();
			String hostAddress = inetAddress.getHostAddress();
			String hostName = inetAddress.getHostName();

			logger.info("Host Address: {}", hostAddress);
			logger.info("Host Name: {}", hostName);
		} catch (UnknownHostException e) {
			logger.error("Error al obtener la información del host: {}", e.getMessage());
		}
	}

	static class ApplicationStartedListener implements ApplicationListener<ContextRefreshedEvent> {
		@Override
		public void onApplicationEvent(ContextRefreshedEvent event) {
			printHostInfo();
			logger.info("La aplicacion ha iniciado correctamente.");

		}
	}

	static class ApplicationFailedListener implements ApplicationListener<ApplicationFailedEvent> {
		@Override
		public void onApplicationEvent(ApplicationFailedEvent event) {
			printHostInfo();
			logger.error("La aplicacion ha fallado al iniciar.");

		}
	}
	private static void logStartupInfo() {
		logger.info("Iniciando la aplicación SpringprojectApplication...");
		printHostInfo();
	}
}
