package com.oxxo.microservice.crearproveedoresorden.unigis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UnigisItemDetail {

    @JsonProperty("RefDocumento")
    private String refDocumento;

    @JsonProperty("Descripcion")
    private String descripcion;

    @JsonProperty("EstadoOrdenItem")
    private String estadoOrdenItem;

    @JsonProperty("UnidadMedida")
    private String unidadMedida;

    @JsonProperty("CodigoProducto")
    private String codigoProducto;

    @JsonProperty("Cantidad")
    private String cantidad;

    @JsonProperty("Producto")
    private UnigisProducto producto;

    @JsonProperty("FormaEntrega")
    private String formaEntrega;

    @JsonProperty("TipoProducto")
    private String tipoProducto;

    @JsonProperty("FechaEntregaDesde")
    private String fechaEntregaDesde;

    @JsonProperty("FechaEntregaHasta")
    private String fechaEntregaHasta;
}
