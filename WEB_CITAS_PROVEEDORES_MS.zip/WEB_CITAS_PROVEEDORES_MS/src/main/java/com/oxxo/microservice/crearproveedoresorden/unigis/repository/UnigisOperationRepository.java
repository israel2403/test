package com.oxxo.microservice.crearproveedoresorden.unigis.repository;

import com.oxxo.microservice.crearproveedoresorden.unigis.model.rms.UnigisOperation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UnigisOperationRepository extends JpaRepository<UnigisOperation,Integer> {

    Optional<UnigisOperation> findUnigisOperationByEnviromentAndOpkey(String enviroment, String opkey);
}
