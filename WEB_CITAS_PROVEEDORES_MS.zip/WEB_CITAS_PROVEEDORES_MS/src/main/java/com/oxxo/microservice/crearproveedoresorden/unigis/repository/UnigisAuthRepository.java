package com.oxxo.microservice.crearproveedoresorden.unigis.repository;


import com.oxxo.microservice.crearproveedoresorden.unigis.model.rms.UnigisAuth;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface  UnigisAuthRepository extends JpaRepository<UnigisAuth,Integer> {

    Optional<UnigisAuth> findUnigisAuthByEnviroment(String enviroment);
}
