package com.oxxo.microservice.crearproveedoresorden.service;

import com.oxxo.microservice.crearproveedoresorden.entity.ProveedorEntity;
import java.util.List;

public interface ICatProveedorService {
        List<ProveedorEntity> listarProveedores();

        void saveAllProveedores(List<ProveedorEntity> proveedorEntityList);
}
