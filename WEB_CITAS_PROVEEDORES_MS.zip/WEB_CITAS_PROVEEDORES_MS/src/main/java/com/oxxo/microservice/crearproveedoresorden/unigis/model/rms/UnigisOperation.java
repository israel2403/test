package com.oxxo.microservice.crearproveedoresorden.unigis.model.rms;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "DT_UNIGIS_OPERATION")
public class UnigisOperation {

    @Id
    @Column(name = "DTIDO")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Integer id;

    @Column(name = "UNI_OPERATION")
    private String operation;

    @Column(name = "UNI_OPKEY")
    private String opkey;

    @Column(name = "UNI_URL")
    private String url;

    @Column(name = "UNI_COMMENTS")
    private String comments;

    @Column(name = "UNI_ENVIROMENT")
    private String enviroment;

    @Column(name = "UNI_ACTIVE")
    private int active;

}
