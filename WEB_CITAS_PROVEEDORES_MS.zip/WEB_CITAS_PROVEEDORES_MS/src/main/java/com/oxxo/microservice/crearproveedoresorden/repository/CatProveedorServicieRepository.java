
package com.oxxo.microservice.crearproveedoresorden.repository;
import com.oxxo.microservice.crearproveedoresorden.entity.ProveedorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface CatProveedorServicieRepository extends JpaRepository<ProveedorEntity, Integer> {
    Set<ProveedorEntity> findByProcesadoLike(String procesado);
}


