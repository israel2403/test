package com.oxxo.microservice.crearproveedoresorden.repository;

import com.oxxo.microservice.crearproveedoresorden.entity.CitaProveedorDeposito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CitaProveedorDepositoRepository extends JpaRepository<CitaProveedorDeposito, Long> {
    CitaProveedorDeposito findByIdProveedor(Integer idProveedor);
}
