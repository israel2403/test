package com.oxxo.microservice.crearproveedoresorden.unigis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UnigisProducto {

    @JsonProperty("RefProducto")
    private String refProducto;

    @JsonProperty("Volumen")
    private String volumen;

    @JsonProperty("Peso")
    private String peso;

    @JsonProperty("Bultos")
    private String bultos;

    @JsonProperty("Alto")
    private String alto;

    @JsonProperty("Ancho")
    private String ancho;

    @JsonProperty("Profundidad")
    private String profundidad;

}
