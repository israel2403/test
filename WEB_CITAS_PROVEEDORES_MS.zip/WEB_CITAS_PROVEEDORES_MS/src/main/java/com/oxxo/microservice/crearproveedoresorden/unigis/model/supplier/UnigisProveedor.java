package com.oxxo.microservice.crearproveedoresorden.unigis.model.supplier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class UnigisProveedor {
    private String barrio;
    private String calle;
    private Integer nbCitasProveedorDepStg;
    private String codigoPostal;
    private String contacto;
    private Boolean depositosReset;
    private String direccion;
    private String email;
    private String entreCalle;
    private String identificadorFiscal;
    private String localidad;
    private String numeroPuerta;
    private Long operacion;
    private String pais;
    private String partido;
    private String proveedorOrdenPadre;
    private String provincia;
    private String razonSocial;
    private String razonSocialFiscal;
    private Boolean recibeNotificaciones;
    private String referenciaExterna;
    private Boolean sincronizarUsuario;
    private Integer telefono;
    private String login;
    private Integer cantidadMaximaCitasPorDia;
}
