package com.oxxo.microservice.crearproveedoresorden.controller;

import com.oxxo.microservice.crearproveedoresorden.service.CatProveedorService;
import com.oxxo.microservice.crearproveedoresorden.service.ScheduledTaskService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("oxxoServicios/apiv1")
@RequiredArgsConstructor
public class ProveedorController {

    private static final Logger logger = LoggerFactory.getLogger(ProveedorController.class);

    private final ScheduledTaskService scheduledTaskService;

    @GetMapping("crear-orden-proveedor")
    public ResponseEntity<Map<String, String>> triggerListarProveedoresV1() throws IOException, InterruptedException {
        logger.info("Received request to trigger listarProveedoresV1");

        try {
            scheduledTaskService.listarProveedoresV1();
            logger.info("listarProveedoresV1 executed successfully");
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (IOException e) {
            logger.error("IOException occurred while executing listarProveedoresV1", e);
            throw e;
        } catch (InterruptedException e) {
            logger.error("InterruptedException occurred while executing listarProveedoresV1", e);
            throw e;
        } catch (Exception e) {
            logger.error("Unexpected error occurred while executing listarProveedoresV1", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
