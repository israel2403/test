package com.oxxo.microservice.crearproveedoresorden.utils;

public enum UnigisOperationsEnum {
    ORDENES_TRABAJO("crOT"),
    PRODUCTO("crPRO"),
    PROVEEDOR("crPRV");

    public final String label;

    UnigisOperationsEnum(String label) {
        this.label = label;
    }
}
