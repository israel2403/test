package com.oxxo.microservice.crearproveedoresorden.unigis.service;

import com.oxxo.microservice.crearproveedoresorden.service.CatProveedorService;
import com.oxxo.microservice.crearproveedoresorden.unigis.model.rms.UnigisOperation;
import com.oxxo.microservice.crearproveedoresorden.unigis.repository.UnigisOperationRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Optional;

@RequiredArgsConstructor
@Service
public class UnigisOperationService {


    private  final UnigisOperationRepository repository;

    private static final Logger logger = LoggerFactory.getLogger(CatProveedorService.class);


    public Optional<UnigisOperation> getActiveEnviromentData(String enviroment, String opkey) {
        logger.info("Fetching active environment data for environment: {} and opkey: {}", enviroment, opkey);
        Optional<UnigisOperation> result = repository.findUnigisOperationByEnviromentAndOpkey(enviroment, opkey);

        if (result.isPresent()) {
            logger.info("Successfully fetched active environment data for environment: {} and opkey: {}", enviroment, opkey);
        } else {
            logger.warn("No active environment data found for environment: {} and opkey: {}", enviroment, opkey);
        }

        return result;
    }
}
