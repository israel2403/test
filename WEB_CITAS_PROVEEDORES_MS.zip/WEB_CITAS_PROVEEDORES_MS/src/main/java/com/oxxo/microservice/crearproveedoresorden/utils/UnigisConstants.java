package com.oxxo.microservice.crearproveedoresorden.utils;

public enum UnigisConstants {
    BEARER("Bearer"),
    OXXO_MS_TEST("OXXO MS TEST"),
    CONTENT_TYPE("Content-Type"),
    APPLICATION_JSON_VALUE("application/json"),
    ACCEPT("text/plain"),
    ACCEPT_ENCODING("gzip, deflate, br"),
    DES("DES"),
    NO_UNIGIS_OPERATION_FOUND("No Unigis Operation found"),
    NO_AUTH_UNIGIS_DATA_FOUND("No Auth Unigis data found"),
    UNIGIS_ERROR("Unigis Error"),
    PROCESADO("P"),
    ERROR_LOG_REGISTER_FAILED("Failed to register in the error log"),
    PROCESS_IND_P("P"),
    PROCESS_IND_E("E"),
    USER_AGENT("User-Agent"),
    ACCEPT_LABEL("Accept"),
    ACCEPT_VALUE("*/*"),
    ACCEPT_ENCODING_LABEL("Accept-Encoding"),
    AUTHORIZATION("Authorization");

    private final String value;

    UnigisConstants(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
