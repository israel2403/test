package com.oxxo.microservice.crearproveedoresorden.unigis.model.supplier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UnigisProveedorEntity {
    @JsonProperty("ApiKey")
    String apiKey;
    List<UnigisProveedor> proveedoresOrden;
}
