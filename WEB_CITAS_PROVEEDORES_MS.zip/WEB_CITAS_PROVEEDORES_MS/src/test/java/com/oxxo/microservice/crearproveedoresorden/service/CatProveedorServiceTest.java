package com.oxxo.microservice.crearproveedoresorden.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.oxxo.microservice.crearproveedoresorden.entity.ProveedorEntity;
import com.oxxo.microservice.crearproveedoresorden.repository.CatProveedorServicieRepository;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@ActiveProfiles("test")
public class CatProveedorServiceTest {

    @Autowired
    private CatProveedorService catProveedorService;

    @Autowired
    private CatProveedorServicieRepository proveedorRepository;

    @BeforeEach
    public void setUp() {
        proveedorRepository.deleteAll();

        ProveedorEntity proveedor1 = new ProveedorEntity();
        proveedor1.setRecibeNotificaciones(1);
        proveedor1.setDepositosReset(1);
        proveedor1.setProcesado("N");
        proveedorRepository.save(proveedor1);

        ProveedorEntity proveedor2 = new ProveedorEntity();
        proveedor2.setRecibeNotificaciones(null);
        proveedor2.setDepositosReset(null);
        proveedor2.setProcesado("N");
        proveedorRepository.save(proveedor2);
    }

    @Test
    public void testGetProveedores() {
        List<ProveedorEntity> result = catProveedorService.get();
        assertEquals(2, result.size());
    }
}
