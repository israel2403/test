package com.oxxo.microservice.crearproveedoresorden.unigis.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oxxo.microservice.crearproveedoresorden.unigis.model.rms.UnigisOperation;
import com.oxxo.microservice.crearproveedoresorden.unigis.repository.UnigisOperationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
public class UnigisOperationServiceTest {

    @Mock
    private UnigisOperationRepository repository;

    @InjectMocks
    private UnigisOperationService service;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
    }

    @Test
    void testGetActiveEnviromentDataFound() throws IOException {
        // Load the JSON file and convert it to a UnigisOperation object
        UnigisOperation operation = objectMapper.readValue(new File("src/test/resources/json/unigis/service/UnigisOperation/unigis.json"), UnigisOperation.class);

        // Ensure the mock repository returns the expected Optional when any String arguments are passed
        when(repository.findUnigisOperationByEnviromentAndOpkey(anyString(), anyString()))
                .thenReturn(Optional.of(operation));

        // Call the service method with specific arguments
        Optional<UnigisOperation> result = service.getActiveEnviromentData(anyString(), anyString());
        System.out.println("result: " + result.isPresent());

        // Verify the result
        assertTrue(result.isPresent(), "Expected operation to be present");
        assertEquals("test_env", result.get().getEnviroment(), "Environment should match");
        assertEquals("test_key", result.get().getOpkey(), "Opkey should match");
    }

    @Test
    void testGetActiveEnviromentDataNotFound() {
        // Use lenient to prevent unnecessary stubbing exception
        lenient().when(repository.findUnigisOperationByEnviromentAndOpkey(anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Call the service method
        Optional<UnigisOperation> result = service.getActiveEnviromentData("test_env", "test_key");

        // Verify the result
        assertTrue(result.isEmpty(), "Expected no operation to be found");
    }
}
